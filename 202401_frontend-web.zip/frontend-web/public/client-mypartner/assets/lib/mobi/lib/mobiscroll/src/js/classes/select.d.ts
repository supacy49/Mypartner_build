import mobiscroll from '../core/core';
export default class Select {
    constructor(element: any, settings: any);
}