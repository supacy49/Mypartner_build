import mobiscroll from '../core/core';
export default class TextArea {
    constructor(element: any, settings: any);
}