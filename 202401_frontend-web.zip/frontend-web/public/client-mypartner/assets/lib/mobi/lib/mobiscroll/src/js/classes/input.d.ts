import mobiscroll from '../core/core';
export default class Input {
    constructor(element: any, settings: any);
}