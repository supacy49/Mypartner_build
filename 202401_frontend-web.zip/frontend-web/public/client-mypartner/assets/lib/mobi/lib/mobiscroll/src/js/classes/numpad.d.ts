import mobiscroll from '../core/core';
export default class Numpad {
    constructor(element: any, settings: any);
}
