import mobiscroll from '../core/core';
export default class Progress {
    constructor(element: any, settings: any);
}